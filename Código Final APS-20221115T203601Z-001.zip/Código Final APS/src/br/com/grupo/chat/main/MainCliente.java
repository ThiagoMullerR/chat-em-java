package br.com.grupo.chat.main;

import br.com.grupo.chat.tela.TelaChat;
import br.com.grupo.chat.backend.*;

public class MainCliente {

	public static void main(String[] args) {
		
		Cliente cliente = new Cliente();
		TelaChat tela = new TelaChat(cliente);
		cliente.setTela(tela);
		
		tela.setVisible(true);

	}

}
