package br.com.grupo.chat.tela;

import java.awt.*;
import java.awt.event.*;
import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.swing.*;

import br.com.grupo.chat.backend.Cliente;
import br.com.grupo.chat.jdbc.dao.RegistraDAO;
import br.com.grupo.chat.jdbc.factory.ConnectionFactory;
import br.com.grupo.chat.jdbc.modelo.Usuario;

public class TelaChat extends JFrame implements ActionListener {

	private JMenuBar mnBarra;
	private JMenu mnMenu;
	private JMenuItem miChat, miCadastro;

	private JPanel cadastro;

	private JButton botCadastrar;
	private JButton botLimparTudo;

	private JPanel preencher;

	private JLabel labCadastro;
	private JLabel labNome;
	private JLabel labEmail;
	private JLabel labCadSenha;
	private JLabel labConfSenha;
	private JLabel labCargo;
	private JLabel labBanner;
	private JTextField texNome;
	private JTextField texEmail;
	private JPasswordField texCadSenha;
	private JPasswordField texConfSenha;
	private JTextField texCargo;
	private ImageIcon bannerCetesb;

	private JPanel chatLogin;

	private JPanel login;

	private JLabel labUser;
	private JLabel labSenha;
	private JLabel labLogin;
	private JLabel logo;
	private JTextField texUser;
	private JPasswordField texSenha;
	private JButton botConect;
	private JButton botSair;
	private ImageIcon logoCetesb;

	private JPanel chat;

	private JScrollPane scRolagemVis;
	private JScrollPane scRolagemEsc;
	private JTextArea txtVisor;
	private JTextArea txtEscreve;
	private JButton botLimpar;
	private JButton botEnviar;

	private JPanel arquivo;

	private JFileChooser escolherArq;
	private JButton botEnviaArq;
	private JButton botSelecionaArq;
	private JButton botBaixaArq;
	private JList<String> listaArq;
	private JScrollPane scRolagemLista;
	private JLabel labRecebeArq;
	private JLabel labEnviaArq;
	private JLabel labSelecionaArq;

	private File arquivoselecionado;

	private Cliente cliente;

	public TelaChat(Cliente cliente) {
		super();
		configurarFrame();
		configuraMenu();
		configurarPainelChatLogin();
		configurarPainelCadastro();
		add(cadastro);
		add(chatLogin);
		chatLogin.setVisible(false);
		this.cliente = cliente;
	}

	private void configuraMenu() {

		miCadastro = new JMenuItem("Cadastro");
		miChat = new JMenuItem("Chat");

		mnMenu = new JMenu("MENU");
		mnMenu.setFont(new Font(null, Font.BOLD, 14));
		mnMenu.add(miCadastro);
		mnMenu.add(miChat);

		mnBarra = new JMenuBar();
		mnBarra.add(mnMenu);
		setJMenuBar(mnBarra);

		miCadastro.addActionListener(this);
		miChat.addActionListener(this);

	}

	private void configurarPainelCadastro() {

		cadastro = new JPanel();
		cadastro.setLayout(null);
		cadastro.setBounds(0, 0, 600, 600);

		configurarPainelPreencher();

		labCadastro = new JLabel("CADASTRO DE USUÁRIO");
		labCadastro.setFont(new Font(null, Font.BOLD, 20));
		labBanner = new JLabel(bannerCetesb);
		botLimparTudo = new JButton("Limpar");
		botLimparTudo.setFont(new Font(null, Font.BOLD, 13));
		botCadastrar = new JButton("Cadastrar");
		botCadastrar.setFont(new Font(null, Font.BOLD, 13));
		bannerCetesb = new ImageIcon(this.getClass().getResource("/img/BannerCetesb.png"));

		labBanner.setBounds(0, 0, 600, 120);
		labCadastro.setBounds(170, 150, 300, 50);
		botCadastrar.setBounds(95, 490, 150, 28);
		botLimparTudo.setBounds(345, 490, 150, 28);

		cadastro.add(labBanner);
		cadastro.add(labCadastro);
		cadastro.add(botLimparTudo);
		cadastro.add(botCadastrar);
		cadastro.add(preencher);

		// Adicionando evento aos botoes
		botCadastrar.addActionListener(this);
		botLimparTudo.addActionListener(this);

		labBanner.setIcon(bannerCetesb);
	}

	private void configurarPainelPreencher() {

		preencher = new JPanel();
		preencher.setLayout(null);
		preencher.setBounds(75, 200, 440, 260);
		// preencher.setBackground(new Color(56,95,162));

		configurarDadosCadastro();

		preencher.add(labNome);
		preencher.add(labEmail);
		preencher.add(labCargo);
		preencher.add(labCadSenha);
		preencher.add(labConfSenha);
		preencher.add(texNome);
		preencher.add(texEmail);
		preencher.add(texCargo);
		preencher.add(texCadSenha);
		preencher.add(texConfSenha);

		preencher.setBorder(BorderFactory.createLoweredBevelBorder());

	}

	private void configurarDadosCadastro() {

		labNome = new JLabel("Nome:");
		labNome.setFont(new Font(null, Font.BOLD, 13));
		labEmail = new JLabel("E-mail:");
		labEmail.setFont(new Font(null, Font.BOLD, 13));
		labCargo = new JLabel("Cargo:");
		labCargo.setFont(new Font(null, Font.BOLD, 13));
		labCadSenha = new JLabel("Senha:");
		labCadSenha.setFont(new Font(null, Font.BOLD, 13));
		labConfSenha = new JLabel("Confirmar senha:");
		labConfSenha.setFont(new Font(null, Font.BOLD, 13));
		texNome = new JTextField();
		texEmail = new JTextField();
		texCargo = new JTextField();
		texCadSenha = new JPasswordField();
		texConfSenha = new JPasswordField();

		// Dimensionando os Componentes
		labNome.setBounds(90, 20, 50, 25);
		labEmail.setBounds(88, 70, 50, 25);
		labCargo.setBounds(88, 120, 50, 25);
		labCadSenha.setBounds(88, 170, 50, 25);
		labConfSenha.setBounds(24, 220, 130, 25);
		texNome.setBounds(150, 20, 250, 25);
		texEmail.setBounds(150, 70, 250, 25);
		texCargo.setBounds(150, 120, 250, 25);
		texCadSenha.setBounds(150, 170, 250, 25);
		texConfSenha.setBounds(150, 220, 250, 25);

	}

	private void configurarPainelChatLogin() {

		chatLogin = new JPanel();
		chatLogin.setLayout(null);
		chatLogin.setBounds(0, 0, 600, 600);

		configurarPainelLogin();
		configurarPainelChat();
		configurarPainelArquivo();

		chatLogin.add(login);
		chatLogin.add(chat);
		chatLogin.add(arquivo);

	}

	private void configurarPainelArquivo() {

		arquivo = new JPanel();
		arquivo.setLayout(null);
		arquivo.setBounds(380, 130, 200, 420);

		configurarDadosArquivo();

		arquivo.add(botBaixaArq);
		arquivo.add(botEnviaArq);
		arquivo.add(botSelecionaArq);
		arquivo.add(labEnviaArq);
		arquivo.add(labSelecionaArq);
		arquivo.add(labRecebeArq);
		arquivo.add(scRolagemLista);

		arquivo.setBorder(BorderFactory.createTitledBorder("ARQUIVOS"));

	}

	private void configurarDadosArquivo() {

		labRecebeArq = new JLabel("RECEBIMENTO DE ARQUIVOS");
		labRecebeArq.setFont(new Font(null, Font.BOLD, 11));
		labEnviaArq = new JLabel("ENVIO DE ARQUIVOS");
		labEnviaArq.setFont(new Font(null, Font.BOLD, 11));
		labSelecionaArq = new JLabel("Arquivo não escolhido", SwingConstants.CENTER);
		labSelecionaArq.setFont(new Font(null, Font.ITALIC, 12));
		botBaixaArq = new JButton("Baixar Arquivo");
		botEnviaArq = new JButton("Enviar Arquivo");
		botSelecionaArq = new JButton("Escolher Arquivo");
		listaArq = new JList();
		scRolagemLista = new JScrollPane(listaArq);

		// Dimensionando os Componentes
		labRecebeArq.setBounds(10, 20, 180, 25);
		labEnviaArq.setBounds(10, 290, 150, 25);
		labSelecionaArq.setBounds(10, 350, 180, 25);
		botBaixaArq.setBounds(25, 250, 150, 25);
		botEnviaArq.setBounds(25, 380, 150, 25);
		botSelecionaArq.setBounds(25, 325, 150, 25);
		scRolagemLista.setBounds(10, 50, 180, 190);

		// Desabilitando os bot�es e caixas de texto antes de conectar
		botBaixaArq.setEnabled(false);
		botEnviaArq.setEnabled(false);
		botSelecionaArq.setEnabled(false);

		// Adicionando evento aos bot�es
		botBaixaArq.addActionListener(this);
		botEnviaArq.addActionListener(this);
		botSelecionaArq.addActionListener(this);

	}

	private void configurarPainelChat() {

		chat = new JPanel();
		chat.setLayout(null);
		chat.setBounds(10, 130, 370, 420);

		configurarDadosChat();

		chat.add(scRolagemVis);
		chat.add(scRolagemEsc);
		chat.add(botLimpar);
		chat.add(botEnviar);
		chat.setBorder(BorderFactory.createTitledBorder("CHAT"));

	}

	private void configurarDadosChat() {

		txtVisor = new JTextArea("");
		txtEscreve = new JTextArea("");
		botLimpar = new JButton("Limpar");
		botEnviar = new JButton("Enviar");
		// botEnviarArq = new JButton("Enviar Arquivo");
		// escolherArq = new JFileChooser();
		// botEnviarArq.addActionListener(this);
		scRolagemEsc = new JScrollPane(txtEscreve);
		scRolagemVis = new JScrollPane(txtVisor);

		// Dimensionando os Componentes
		scRolagemVis.setBounds(20, 25, 330, 200);
		scRolagemEsc.setBounds(20, 240, 330, 130);
		botLimpar.setBounds(140, 380, 100, 25);
		botEnviar.setBounds(250, 380, 100, 25);

		// Desabilitando os bot�es e caixas de texto antes de conectar
		botEnviar.setEnabled(false);
		botLimpar.setEnabled(false);
		txtVisor.setEnabled(false);
		txtVisor.setEditable(false);
		txtEscreve.setEnabled(false);

		// Adicionando evento aos bot�es
		botLimpar.addActionListener(this);
		botEnviar.addActionListener(this);
	}

	private void configurarPainelLogin() {

		login = new JPanel();
		login.setLayout(null);
		login.setBounds(0, 0, 600, 120);
		login.setBackground(new Color(56, 95, 162));

		configurarDadosLogin();
		login.add(labUser);
		login.add(labSenha);
		login.add(labLogin);
		login.add(texUser);
		login.add(texSenha);
		login.add(botConect);
		login.add(botSair);
		login.add(logo);
	}

	private void configurarDadosLogin() {
		labUser = new JLabel("Usuário:");
		labSenha = new JLabel("Senha:");
		labLogin = new JLabel("LOGIN:");
		logo = new JLabel(logoCetesb);
		texUser = new JTextField();
		texSenha = new JPasswordField();
		botConect = new JButton("Conectar");
		botSair = new JButton("Sair");
		logoCetesb = new ImageIcon(this.getClass().getResource("/img/LogoCetesb.png"));

		// Dimensionando os Componentes
		labUser.setBounds(40, 40, 50, 25);
		labSenha.setBounds(40, 70, 50, 25);
		labLogin.setBounds(20, 10, 80, 25);
		texUser.setBounds(100, 40, 170, 25);
		texSenha.setBounds(100, 70, 170, 25);
		botConect.setBounds(290, 40, 100, 25);
		botSair.setBounds(290, 70, 100, 25);
		logo.setBounds(450, 10, 100, 100);

		// Adicionando evento aos bot�es
		botConect.addActionListener(this);
		botSair.addActionListener(this);

		// Desabilitando os bot�es antes de conectar
		botSair.setEnabled(false);

		logo.setIcon(logoCetesb);

		labUser.setForeground(Color.white);
		labSenha.setForeground(Color.white);
		labLogin.setForeground(Color.white);

	}

	private void configurarFrame() {
		setTitle("Comunicação Interna - CETESB");
		setSize(new Dimension(600, 620));
		setLayout(null);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLocationRelativeTo(null);
	}

	public void atualizarVisor(String remetente, String cargo, String texto) {
		txtVisor.append(String.format(" %s (%s): %s\n", remetente,cargo, texto));
	}
	
	public void atualizarVisor(String remetente, String texto) {
		txtVisor.append(String.format(" %s: %s\n", remetente, texto));
	}

	public void atualizarLista(DefaultListModel<String> novalista) {
		listaArq.setModel(novalista);
		botBaixaArq.setEnabled(true);
	}

	public void sucessoRecArq(String nomearq) {
		labSelecionaArq.setText("Download concluído.");
		JOptionPane.showMessageDialog(null, String.format("Download do arquivo \"%s\" realizado com sucesso!", nomearq), "DOWNLOAD DE ARQUIVO",JOptionPane.INFORMATION_MESSAGE);
	}
	
	public void sucessoEnvArq(String nomearq) {
		labSelecionaArq.setText("Envio concluído.");
		JOptionPane.showMessageDialog(null, String.format("Envio do arquivo \"%s\" realizado com sucesso!", nomearq), "ENVIO DE ARQUIVO",JOptionPane.INFORMATION_MESSAGE);
	}

	// Acoes dos botoes
	public void actionPerformed(ActionEvent ae) {

		Object obj = ae.getSource();

		// Menu

		if (obj.equals(miCadastro)) {

			cadastro.setVisible(true);
			chatLogin.setVisible(false);

		}

		if (obj.equals(miChat)) {

			chatLogin.setVisible(true);
			cadastro.setVisible(false);

		}

		// Painel de Login

		if (obj.equals(botConect)) {

			if (!texUser.getText().equals("") && !texSenha.getText().equals("")) {

				int conecta = 0;

				try {
					conecta = cliente.executa(texUser.getText(), texSenha.getText());
				} catch (ClassNotFoundException | IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

				if (conecta == 1) {
					botEnviar.setEnabled(true);
					botLimpar.setEnabled(true);
					txtVisor.setEnabled(true);
					txtEscreve.setEnabled(true);
					botSair.setEnabled(true);
					botSelecionaArq.setEnabled(true);
					listaArq.setEnabled(true);

					// Desabilitando o botao de conexao depois que a conexao eh feita
					botConect.setEnabled(false);
					// Apagando usuario e senha da caixa de texto depois da conexao
					texUser.setText("");
					texSenha.setText("");
				} else {
					JOptionPane.showMessageDialog(null, "O usuário informado não existe\nPor favor, cadastre", "Erro",
							JOptionPane.ERROR_MESSAGE);
					botConect.setEnabled(true);
					botSair.setEnabled(false);
				}

			} else {
				JOptionPane.showMessageDialog(null, "Usuario e Senha devem ser informados.", "INFORMAÇÃO FALTANTE",
						JOptionPane.ERROR_MESSAGE);

			}

		}

		if (obj.equals(botSair)) {

			// Finalizar a conexao

			// Desbilitando os botoes depois que a conexao eh desfeita
			botEnviar.setEnabled(false);
			botLimpar.setEnabled(false);
			txtVisor.setEnabled(false);
			txtEscreve.setEnabled(false);
			botSair.setEnabled(false);
			botBaixaArq.setEnabled(false);
			botEnviaArq.setEnabled(false);
			botSelecionaArq.setEnabled(false);
			listaArq.setEnabled(false);

			// Habilitando o botao de conexao depois de desconectar
			botConect.setEnabled(true);

			// Apagando o conteudo do chat depois de sair da conexao
			txtEscreve.setText("");
			txtVisor.setText("");
			// pensar em uma forma de apagar os arquivos disponiveis na lista

		}

		// Painel do Chat

		if (obj.equals(botLimpar)) {

			txtEscreve.setText("");

		}

		if (obj.equals(botEnviar)) {

			// Enviar a mensagem pro servidor

			String textoCaixa = txtEscreve.getText();

			if (!textoCaixa.isBlank()) {
				atualizarVisor("Você", textoCaixa);
				cliente.mensagemTela(textoCaixa);
			}

			// Apagar a mensagem da area de escrita no momento do envio
			txtEscreve.setText("");

		}

		// Painel dos Arquivos

		if (obj.equals(botSelecionaArq)) {

			// Selecionando o arquivo desejado

			JFileChooser file = new JFileChooser();

			file.setFileSelectionMode(JFileChooser.FILES_ONLY);
			int i = file.showSaveDialog(null);

			if (i == 1) {
				labSelecionaArq.setText("Arquivo não escolhido");
				botEnviaArq.setEnabled(false);
			} else {
				arquivoselecionado = file.getSelectedFile();
				System.out.println(arquivoselecionado.getName());
				labSelecionaArq.setText(String.format("Arquivo: %s", arquivoselecionado.getName()));
				botEnviaArq.setEnabled(true);
			}

		}

		if (obj.equals(botEnviaArq)) {
			cliente.arqTela(arquivoselecionado);
			labSelecionaArq.setText(String.format("Enviando %s...", arquivoselecionado.getName()));
		}

		if (obj.equals(botBaixaArq)) {

			System.out.println(listaArq.getSelectedIndex());
			cliente.baixarArq(listaArq.getSelectedIndex());

			labSelecionaArq.setText(String.format("Baixando %s...", listaArq.getSelectedValue()));


		}

		// Tela de Cadastro

		if (obj.equals(botLimparTudo)) {

			texNome.setText("");
			texEmail.setText("");
			texCadSenha.setText("");
			texConfSenha.setText("");
			texCargo.setText("");

		}

		if (obj.equals(botCadastrar)) {

			final String nome = texNome.getText();
			final String email = texEmail.getText();
			final String cadSenha = texCadSenha.getText();
			final String confSenha = texConfSenha.getText();
			final String cargo = texCargo.getText();

			if (cadSenha.equals(confSenha)) {

				// Peguei do seu codigo do TestaCadastro

				Usuario usuario = new Usuario(nome, cadSenha);
				usuario.setEmail(email);
				usuario.setCargo(cargo);

				try (final var conexao = new ConnectionFactory().recuperarConexao()) {
					final var registraDAO = new RegistraDAO(conexao);

					registraDAO.registra(usuario);

				} catch (SQLException e) {
					e.printStackTrace();
				}

				JOptionPane.showMessageDialog(null, "Usuario " + usuario.getNome() + " cadastrado com sucesso!",
						"CADASTRO", JOptionPane.INFORMATION_MESSAGE);

				texNome.setText("");
				texEmail.setText("");
				texCadSenha.setText("");
				texConfSenha.setText("");
				texCargo.setText("");

			}

			else {

				JOptionPane.showMessageDialog(null, "Senhas inseridas sao diferentes!", "SENHAS DISTINTAS",
						JOptionPane.ERROR_MESSAGE);

			}

		}

	}



}