package br.com.grupo.chat.backend;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Objects;
import java.util.Scanner;
import java.util.UUID;

import javax.swing.DefaultListModel;

import com.mysql.cj.protocol.a.authentication.MysqlClearPasswordPlugin;

import br.com.grupo.chat.jdbc.modelo.Usuario;
import br.com.grupo.chat.tela.TelaChat;

public class Cliente {

	private Usuario usuario;
	private String host;
	private int porta;
	private Usuario usuarioLogado;
	static TelaChat tela;
//	private ArrayList<String> arqIds = new ArrayList<>();
	private DefaultListModel<String> arqIds = new DefaultListModel<String>();
	private DefaultListModel<String> arqNomes = new DefaultListModel<String>();

//	private ArrayList<String> arqNomes = new ArrayList<>();

	public Cliente() {
	}

	public void setTela(TelaChat tela) {
		this.tela = tela;
	}

	public void arqTela(File arquivo) {
		EnviarArquivo ea = new EnviarArquivo(ER.saida, arquivo);
		new Thread(ea).start();
	}

	public void mensagemTela(String texto) {
		Enviar.procMsg(texto);
	}

	public void baixarArq(int indexarq) {
		String uuid = arqIds.get(indexarq);
		System.out.println("requisitando arquivo "+ uuid);
		Enviar.requisitarArq(uuid);
	}

	public int executa(String nome, String senha) throws UnknownHostException, IOException, ClassNotFoundException {
		int conecta = 0;

		System.out.println("Login recebido da interface");

		Usuario usuario = new Usuario(nome, senha);

//		System.out.println(usuario);

		Socket conexao = new Socket("192.168.0.100", 12345);
		if (conexao != null) {
			System.out.println("Conexão com o servidor realizada");
			ER.conexao = conexao;

			ObjectOutputStream saida = null;
			saida = new ObjectOutputStream(ER.conexao.getOutputStream());
			ER.saida = saida;

			ObjectInputStream entrada = null;
			entrada = new ObjectInputStream(ER.conexao.getInputStream());

//			System.out.println("O cliente se conectou ao servidor!");

			saida.writeObject(usuario);

			Object obj = entrada.readObject();

			if (obj.getClass() == Usuario.class) {
				ER.nome = ((Usuario) obj).getNome();
				ER.cargo = ((Usuario) obj).getCargo();
				new Thread(new Enviar(saida)).start();
				new Thread(new Receber(entrada)).start();
				conecta = 1;
			} else {
				conecta = 0;
			}


		}
		return conecta;

	}

// Lucas
	abstract class ER implements Runnable {

		static Socket conexao;
		static String nome;
		static String cargo;
		static Scanner teclado;
		static ObjectOutputStream saida;

		public static void enviar(Mensagem msg, ObjectOutputStream saida) {
			try {
//			System.out.println(msg);
				saida.writeObject(msg);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}

	class EnviarArquivo extends ER {

		ObjectOutputStream saida = null;
		String caminho = null;
		String nomearq = null;
		File fi = null;

		EnviarArquivo(ObjectOutputStream saida, File fi) {
			this.saida = saida;
			this.fi = fi;
			this.nomearq = fi.getName();
			System.out.println("Enviando arquivo "+this.nomearq);
		}

		@Override
		public void run() {

			String uuid = UUID.randomUUID().toString();

			FileInputStream input = null;
			try {
				input = new FileInputStream(fi);
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			int b = 0;

			try {
				while (input.available() > 0) {
					b = input.read();
					Mensagem msg = new MensagemTransferencia(ER.nome, nomearq, b, uuid);
//					System.out.println(msg);
					enviar(msg, saida);
				}
				Mensagem msg = new MensagemTransferencia(ER.nome, nomearq, -1, uuid);
//				System.out.println(msg);
				enviar(msg, saida);
				tela.sucessoEnvArq(nomearq);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			try {
				input.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}

	}

	class Enviar extends ER {

		static ObjectOutputStream saida = null;

		public static void requisitarArq(String uuid) {
			MensagemRequisitarArquivo msg = new MensagemRequisitarArquivo(uuid);
			System.out.println(msg);
			enviar(msg, saida);
		}

		public static void procMsg(String texto) {
			Mensagem msg = new MensagemUsuario(ER.nome, ER.cargo, texto);
//			System.out.println("procmsg: " + msg.toString());
			enviar(msg, saida);
		}

		Enviar(ObjectOutputStream saida) {
			this.saida = saida;
		}

		public void run() {
//			try {
//				saida = new ObjectOutputStream(ER.conexao.getOutputStream());
//			} catch (IOException e1) {
//				// TODO Auto-generated catch block
//				e1.printStackTrace();
//			}

//			while (ER.teclado.hasNextLine()) {
//				String line = ER.teclado.nextLine();
//
//				try {
//					if (line.charAt(0) == '/') {
//						String[] caminho;
//						String nomearquivo;
//						caminho = line.split("/");
//						nomearquivo = caminho[caminho.length - 1];
//
//						EnviarArquivo ea = new EnviarArquivo(saida, line, nomearquivo);
//						new Thread(ea).start();
//
//					} else if (line.charAt(0) == 'd') {
//						String[] linha;
//						String uuid;
//						linha = line.split(",");
//						uuid = linha[1];
//
//						ReceberArquivo ra = new ReceberArquivo(uuid, saida);
//						new Thread(ra).start();
//					} else {
//						Mensagem msg = new MensagemUsuario(ER.nome, line);
//						enviar(msg, saida);
//					}
//
//				} catch (Exception e) {
//
//				}
//			}
		}

	}

	class Receber extends ER {

		ObjectInputStream entrada = null;

		Receber(ObjectInputStream entrada) {
			this.entrada = entrada;
//			System.out.println("ent rec " + entrada);
//			System.out.println("ent obj " + this.entrada);
		}

		@Override
		public void run() {

			GerenciadorArquivo ga = new GerenciadorArquivo("C:\\Downloads\\");
			int terminado = 0;

			while (true) {
				Mensagem msg = null;

				try {
//					System.out.println(entrada);
					msg = (Mensagem) entrada.readObject();

					if (msg.getClass() == MensagemUsuario.class) {
//						System.out.println(msg);
						tela.atualizarVisor(msg.remetente, ((MensagemUsuario) msg).cargo, ((MensagemUsuario) msg).mensagem);
					} else if (msg.getClass() == MensagemListaArquivos.class) {
						if (!Objects.isNull(arqIds)) {
							arqIds.clear();
						}
						if (!Objects.isNull(arqNomes)) {
							arqNomes.clear();
						}

						String lista = ((MensagemListaArquivos) msg).lista;

						String[] arqs = lista.split("\\*");

						for (int i = 1; i < arqs.length; i++) {
							String[] info = arqs[i].split(":");
							arqIds.addElement(info[0]);
							arqNomes.addElement(info[2]);
						}

//						System.out.println(arqNomes);
						System.out.println("Novos arquivos recebidos");
						tela.atualizarLista(arqNomes);
					} else if (msg.getClass() == MensagemTransferencia.class) {
//						System.out.println(msg);

						terminado = ga.Escreve((MensagemTransferencia) msg);

						if (terminado == 1) {
//							System.out.println("sucesso");
							tela.sucessoRecArq(((MensagemTransferencia) msg).nomearquivo);
						}

					}

				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					System.exit(1);
				}

			}
		}
	}
}
