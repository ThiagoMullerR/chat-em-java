package br.com.grupo.chat.backend;

import java.io.File;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.util.Hashtable;

import br.com.grupo.chat.backend.Cliente.ER;

public class GerenciadorArquivo {

	static String listaArquivos = null;
	static Hashtable<String, FileOutputStream> arqAbertos = new Hashtable();
	static String caminho = null;
	static int user = 0;

	GerenciadorArquivo(String caminho) {
		this.caminho = caminho;
		if(ER.nome == null) {
			GerenciadorArquivo.user = 0;
		} else {
			GerenciadorArquivo.user = 1;
		}
//		System.out.println("userrrrrrrrr "+user);
	}

	public int Escreve(MensagemTransferencia msg) throws Exception {
		int terminado = 0;
		
		File fo;
		if (!GerenciadorArquivo.arqAbertos.containsKey(msg.uuid)) {
			if(GerenciadorArquivo.user==1) {
				fo = new File(caminho + msg.nomearquivo);
//				System.out.println("user: "+GerenciadorArquivo.user+" - "+fo.getAbsolutePath());
			}else {
				fo = new File(caminho + msg.uuid);
//				System.out.println("user: "+GerenciadorArquivo.user+" - "+fo.getAbsolutePath());
			}
			System.out.println("Escrevendo arquivo para "+fo.getAbsolutePath());

//			System.out.println(fo.getAbsolutePath());
			fo.createNewFile();

			FileOutputStream output = new FileOutputStream(fo);
			GerenciadorArquivo.arqAbertos.put(msg.uuid, output);

			Escreve(msg);
		} else {
			FileOutputStream output = (FileOutputStream) GerenciadorArquivo.arqAbertos.get(msg.uuid);

			if (msg.bytearq == -1) {
				output.close();
				GerenciadorArquivo.arqAbertos.remove(msg.uuid);
				System.out.println(String.format("Arquivo Recebido: %s - %s, %s", msg.uuid,msg.remetente,msg.nomearquivo));

				String info = String.format("%s:%s:%s", msg.uuid, msg.remetente, msg.nomearquivo);
				GerenciadorArquivo.listaArquivos += String.format("*%s", info);
					
				terminado = 1;
				System.out.println("Transferencia finalizada com sucesso.");
			} else {
				output.write(msg.bytearq);
				terminado = 0;
			}

		}
		
		return terminado;
	}
}
