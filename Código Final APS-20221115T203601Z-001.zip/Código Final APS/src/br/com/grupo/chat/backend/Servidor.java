
package br.com.grupo.chat.backend;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintStream;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Hashtable;
import java.util.List;
import java.util.Objects;

import br.com.grupo.chat.jdbc.dao.LoginDAO;
import br.com.grupo.chat.jdbc.factory.ConnectionFactory;
import br.com.grupo.chat.jdbc.modelo.Usuario;

public class Servidor {
	private int porta;
	private List<PrintStream> clientes;
	private String user;
	private Usuario usuario;
	private Usuario usuarioLogado;

//	private List<Usuario> usuariosOnline = new ArrayList<Usuario>();

	public static void main(String[] args) throws IOException, SQLException {

		System.out.println("Servidor Iniciado.");

		ServerSocket servidor = new ServerSocket(12345);
		String ip = InetAddress.getLocalHost().getHostAddress();
		int porta = servidor.getLocalPort();
		Connection conexaoDB = new ConnectionFactory().recuperarConexao();
//		System.out.println("db: " + conexaoDB);
		LoginDAO loginDAO = new LoginDAO(conexaoDB);
//		System.out.println("db: " + loginDAO);

		while (true) {
			Socket conexao = servidor.accept();

			conexaoCliente novaConexao = new conexaoCliente(conexao, conexaoDB, loginDAO);
			new Thread(novaConexao).start();
		}
	}

}

// lucas

class transferirArquivo implements Runnable {

	String nomearquivo = null;
	int bytearq = 0;
	String uuid = null;
	String caminho = "D:\\servidor\\";
	ObjectOutputStream saida = null;

	transferirArquivo(MensagemRequisitarArquivo msg, ObjectOutputStream saida) {
		this.caminho = this.caminho + msg.uuid;
		this.saida = saida;
		this.uuid = msg.uuid;
		
		String[] arqs = GerenciadorArquivo.listaArquivos.split("\\*");
//		System.out.println("arqs "+Arrays.toString(arqs));
		
		for(int i = 1; i < arqs.length; i++) {
			String[] info = arqs[i].split(":");
			System.out.println("info "+Arrays.toString(info));
			
			if(info[0].equals(this.uuid)) {
				System.out.println("match");
				this.nomearquivo = info[2];
				break;
			}
		}
		
		System.out.println("metodo transarq nome do arq: "+this.nomearquivo);
	}

	@Override
	public void run() {

		File fi = new File(caminho);
		FileInputStream input = null;
		try {
			input = new FileInputStream(fi);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		int b = 0;

		try {
			while (input.available() > 0) {

				b = input.read();
				Mensagem msg = new MensagemTransferencia("servidor", nomearquivo, b, uuid);
//					System.out.println(msg);
				saida.writeObject(msg);
			}
			Mensagem msg = new MensagemTransferencia("servidor", nomearquivo, -1, uuid);
//				System.out.println(msg);
			saida.writeObject(msg);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		try {
			input.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}

class Broadcaster {

	public void broadcast(Mensagem msg, ObjectOutputStream output) {

		conexaoCliente.listaClientes.forEach((outputlista) -> {

			if (output != outputlista) {
				try {
					outputlista.writeObject(msg);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}

		});

	}

}

// TrataCLiente?
class conexaoCliente implements Runnable {
	private Socket conexao;
	private Connection conexaoDB;
	private LoginDAO loginDAO;
	private Object usuarioLogado;
	static ArrayList<ObjectOutputStream> listaClientes = new ArrayList<>();
	static GerenciadorArquivo ga = new GerenciadorArquivo("D:\\servidor\\");
	static Broadcaster bd = new Broadcaster();

	conexaoCliente(Socket conexao, Connection conexaoDB, LoginDAO loginDAO) {
		this.conexao = conexao;
		this.conexaoDB = conexaoDB;
		this.loginDAO = loginDAO;
		System.out.println("Novo cliente conectado");
	}

	@Override
	public void run() {

//		System.out.println("Nova Conexão: " + conexao);

		ObjectInputStream entrada = null;
		try {
			entrada = new ObjectInputStream(conexao.getInputStream());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		ObjectOutputStream saida = null;
		try {
			saida = new ObjectOutputStream(conexao.getOutputStream());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		Usuario usuario = null;
		Usuario usuarioLogado = null;
		try {
			usuario = (Usuario) entrada.readObject();
		} catch (ClassNotFoundException | IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		try {
			usuarioLogado = loginDAO.logar(usuario);
//			System.out.println(usuarioLogado);
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

//		System.out.println("acabou de chamar" + usuarioLogado.toString());

		if (Objects.isNull(usuarioLogado) == true) {
//			System.out.println("é null");
			MensagemLogin sucesso = new MensagemLogin(0);
			System.out.println("Usuario autenticado com sucesso");
			try {
				saida.writeObject(sucesso);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			Thread.interrupted();
		} else {
//			MensagemLogin sucesso = new MensagemLogin(1);
			try {
				saida.writeObject(usuarioLogado);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			listaClientes.add(saida);
//			System.out.println(listaClientes);
			
			int terminado = 0;

			while (true) {
				Mensagem msg = null;

				try {
					msg = (Mensagem) entrada.readObject();
					System.out.println(msg);
				} catch (ClassNotFoundException | IOException e) {
//					// TODO Auto-generated catch block
					e.printStackTrace();
				}
//
				if (msg.getClass() == MensagemUsuario.class) {
					bd.broadcast(msg, saida);
				} else if (msg.getClass() == MensagemTransferencia.class) {
					try {
						terminado = ga.Escreve((MensagemTransferencia) msg);
						
						if(terminado == 1) {
							MensagemListaArquivos msglista = new MensagemListaArquivos(GerenciadorArquivo.listaArquivos);
							System.out.println(msglista);
							bd.broadcast(msglista, saida);
						}
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				} else if (msg.getClass() == MensagemRequisitarArquivo.class) {
					transferirArquivo ta = new transferirArquivo((MensagemRequisitarArquivo) msg, saida);
					new Thread(ta).start();
				}

//				System.out.println(msg);
			}

		}

	}
}